"""
Backend BÁSICO com ORM — mesma ideia da versão SQL puro (uma tabela,
itens como JSON na própria linha, sem autenticação), só trocando o
"como fala com o banco".

Para rodar:
    pip install fastapi "uvicorn[standard]" sqlalchemy --break-system-packages
    uvicorn main:app --reload
"""

import datetime

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

import schemas
from database import Base, engine, get_db
from models import Lista

Base.metadata.create_all(bind=engine)  # cria a tabela a partir da classe Lista

app = FastAPI(title="Minhas Compras — básico com ORM")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def calcular_total(itens: list[schemas.ItemInput]) -> float:
    return sum(item.unit_price * item.quantity for item in itens)


@app.get("/listas", response_model=list[schemas.ListaResumo])
def listar_listas(db: Session = Depends(get_db)):
    # SQL puro seria: "SELECT * FROM listas ORDER BY created_at DESC"
    return db.query(Lista).order_by(Lista.created_at.desc()).all()


@app.get("/listas/{lista_id}", response_model=schemas.ListaDetalhe)
def detalhe_lista(lista_id: int, db: Session = Depends(get_db)):
    # SQL puro seria: "SELECT * FROM listas WHERE id = ?"
    lista = db.query(Lista).filter(Lista.id == lista_id).first()
    if lista is None:
        raise HTTPException(status_code=404, detail="Lista não encontrada")
    return lista


@app.post("/listas", response_model=schemas.ListaResumo, status_code=201)
def criar_lista(dados: schemas.ListaCriar, db: Session = Depends(get_db)):
    total = calcular_total(dados.itens) if dados.status == "done" else 0
    completed_at = datetime.datetime.utcnow() if dados.status == "done" else None

    nova_lista = Lista(
        name=dados.name,
        kind=dados.kind,
        status=dados.status,
        itens=[item.model_dump() for item in dados.itens],  # vira JSON sozinho
        total=total,
        completed_at=completed_at,
    )
    db.add(nova_lista)     # SQL puro seria: "INSERT INTO listas (...) VALUES (...)"
    db.commit()            # confirma a gravação
    db.refresh(nova_lista) # busca de volta o id gerado, created_at, etc.
    return nova_lista


@app.put("/listas/{lista_id}/finalizar", response_model=schemas.ListaResumo)
def finalizar_lista(lista_id: int, dados: schemas.FinalizarInput, db: Session = Depends(get_db)):
    lista = db.query(Lista).filter(Lista.id == lista_id).first()
    if lista is None:
        raise HTTPException(status_code=404, detail="Lista não encontrada")

    # O ponto-chave continua igual à versão SQL puro: atualiza a MESMA
    # linha (mesmo objeto "lista"), não cria uma nova. Aqui isso significa
    # só trocar os atributos do objeto Python — o SQLAlchemy percebe a
    # mudança sozinho e gera o UPDATE na hora do commit.
    lista.itens = [item.model_dump() for item in dados.itens]
    lista.total = calcular_total(dados.itens)
    lista.status = "done"
    lista.completed_at = datetime.datetime.utcnow()

    db.commit()             # SQL puro seria: "UPDATE listas SET ... WHERE id = ?"
    db.refresh(lista)
    return lista


@app.delete("/listas/{lista_id}", status_code=204)
def cancelar_lista(lista_id: int, db: Session = Depends(get_db)):
    lista = db.query(Lista).filter(Lista.id == lista_id).first()
    if lista is None:
        raise HTTPException(status_code=404, detail="Lista não encontrada")
    db.delete(lista)   # SQL puro seria: "DELETE FROM listas WHERE id = ?"
    db.commit()
